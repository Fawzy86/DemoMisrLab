$('document').ready(function(){

	    $('#Grid').mixitup();
});