// jQuery $('document').ready(); function 
$('document').ready(function(){
	/* ---------- Bootstrap Wysiwig ---------- */
	$('#editor').wysiwyg();

	/* ---------- Bootstrap Colorpicker ---------- */
	$('#colorpicker').colorpicker();

});