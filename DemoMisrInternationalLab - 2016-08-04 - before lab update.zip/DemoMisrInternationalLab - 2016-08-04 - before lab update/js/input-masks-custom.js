jQuery(function($){
   $("#date").mask("99/99/9999");
   $("#phone").mask("(999) 999-9999");
   $("#taxid").mask("99-9999999");
   $("#phext").mask("(999) 999-9999? x99999");
   $("#ssn").mask("999-99-9999");
   $("#percent").mask("99%");
   $("#pkey").mask("a*-999-a999");
   $("#eyescript").mask("~9.99 ~9.99 999");
   $("#currency").mask("$99,99,99,99");
});