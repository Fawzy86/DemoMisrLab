﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DemoMisrInternationalLab.Controllers
{
    public class TestDragController : Controller
    {
        //
        // GET: /TestDrag/
        public ActionResult Index()
        {
            return View();
        }
	}
}